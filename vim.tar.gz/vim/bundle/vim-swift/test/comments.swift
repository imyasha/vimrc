// this is a comment

/* this is also a comment,
   but written over multiple lines */
